package com.java24hours;

class Salution {
    public static void main(String[] arguments) {
        // java program goes here
        String greeting = "Saluton Mondo!";
        System.out.println(greeting);
    }
}