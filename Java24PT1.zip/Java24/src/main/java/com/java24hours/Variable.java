package com.java24hours;

class Variable {
    public static void main(String[] arguments) {
        // variables here
        float  gradePointAverage;
        char key = 'C';
        String productName = "Larvets";
        byte escapeKey = 27;
        short roomNumber = 222;
        long salary = 264400000;
        long salarytwo = 264_400_000; 
        // more readable underscores not counted
        boolean gameOver = false;
        double pi = 3.14;
        int mileage = 300;
        int totalmileage = mileage;
        // float pi = 3.14F;
        final int TOUCHDOWN = 6;
        final int FIELDGOAL = 3;
        final int PAT = 1;
        // operators
        double weight = 205;
        weight = weight + 10;
        weight = weight - 10;
        weight = weight / 3;
        // ignore warning triple use of variable
        int remainder = 245 % 3;
       // int total = 500 + (score * 12);
        
    }
}